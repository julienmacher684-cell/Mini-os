#include <stdint.h>

/* ---------- Ein- und Ausgabeports ---------- */
static inline uint8_t inb(uint16_t port) {
    uint8_t r;
    __asm__ volatile("inb %1, %0" : "=a"(r) : "Nd"(port));
    return r;
}

static inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

/* ---------- VGA-Textausgabe ---------- */
#define VGA   ((volatile uint16_t *)0xB8000)
#define COLS  80
#define ROWS  25
#define COLOR 0x07   /* hellgrau auf schwarz */

static int row = 0, col = 0;

static void scroll(void) {
    for (int r = 1; r < ROWS; r++)
        for (int c = 0; c < COLS; c++)
            VGA[(r - 1) * COLS + c] = VGA[r * COLS + c];
    for (int c = 0; c < COLS; c++)
        VGA[(ROWS - 1) * COLS + c] = ' ' | (COLOR << 8);
    row = ROWS - 1;
}

static void newline(void) {
    col = 0;
    if (++row >= ROWS) scroll();
}

static void putc(char ch) {
    if (ch == '\n') { newline(); return; }
    if (ch == '\b') {
        if (col > 0) {
            col--;
            VGA[row * COLS + col] = ' ' | (COLOR << 8);
        }
        return;
    }
    VGA[row * COLS + col] = (uint16_t)ch | (COLOR << 8);
    if (++col >= COLS) newline();
}

static void puts(const char *s) {
    while (*s) putc(*s++);
}

static void clear(void) {
    for (int i = 0; i < COLS * ROWS; i++)
        VGA[i] = ' ' | (COLOR << 8);
    row = col = 0;
}

/* ---------- Tastatur (PS/2, Scancode Set 1, nur Kleinbuchstaben) ---------- */
static const char scancode_map[64] = {
    0,   0,   '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b', '\t',
    'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n', 0,  'a', 's',
    'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0,  '\\', 'z', 'x', 'c', 'v',
    'b', 'n', 'm', ',', '.', '/', 0,   '*', 0,   ' ',
};

static char getkey(void) {
    for (;;) {
        if (!(inb(0x64) & 1)) continue;      /* Puffer leer? */
        uint8_t sc = inb(0x60);
        if (sc & 0x80) continue;             /* Taste losgelassen, ignorieren */
        if (sc < sizeof(scancode_map) && scancode_map[sc])
            return scancode_map[sc];
    }
}

/* ---------- Mini-Shell ---------- */
static char line[128];
static int len = 0;

static int starts_with(const char *s, const char *prefix) {
    while (*prefix) {
        if (*s != *prefix) return 0;
        s++; prefix++;
    }
    return *s == '\0' || *s == ' ';
}

static int streq(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}

static void prompt(void) {
    puts("mini> ");
}

static void run(const char *cmd) {
    if (!*cmd) return;

    if (streq(cmd, "help")) {
        puts("Befehle:\n");
        puts("  help          Diese Hilfe anzeigen\n");
        puts("  echo <text>   Text ausgeben\n");
        puts("  clear         Bildschirm leeren\n");
        puts("  reboot        Neustarten\n");
    } else if (streq(cmd, "clear")) {
        clear();
    } else if (streq(cmd, "reboot")) {
        outb(0x64, 0xFE);                    /* Tastatur-Controller: Reset */
        for (;;) __asm__ volatile("hlt");
    } else if (starts_with(cmd, "echo")) {
        const char *arg = cmd + 4;
        if (*arg == ' ') arg++;
        puts(arg);
        putc('\n');
    } else {
        puts("Unbekannter Befehl: ");
        puts(cmd);
        putc('\n');
    }
}

void kernel_main(void) {
    clear();
    puts("Mini OS v0.1\n");
    puts("Tippe 'help' fuer eine Befehlsliste.\n\n");
    prompt();

    for (;;) {
        char c = getkey();
        if (c == '\n') {
            putc('\n');
            line[len] = '\0';
            run(line);
            len = 0;
            prompt();
        } else if (c == '\b') {
            if (len > 0) { len--; putc('\b'); }
        } else if (len < (int)sizeof(line) - 1) {
            line[len++] = c;
            putc(c);
        }
    }
}
